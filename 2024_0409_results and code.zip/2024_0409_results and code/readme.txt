0 : long cable - short cable, 100MOhm
1 : long cable - short cable, 100MOhm
2 : long cable - short cable, 100MOhm
3 : short cable - short cable, 100MOhm
4 : short cable - short cable, 100MOhm
5 : short cable - short cable, 100MOhm
6 : short cable - long cable, 100MOhm
7 : short cable - long cable, 100MOhm
8 : short cable - long cable, 100MOhm
9 : long cable - long cable, 100MOhm
10 : long cable - long cable, 100MOhm
11 : long cable - long cable, 100MOhm

long cable length  - 2930 [mm]
short cable length - 937 [mm]
