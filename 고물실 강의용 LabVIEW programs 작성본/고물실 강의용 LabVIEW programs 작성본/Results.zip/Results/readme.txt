Overall : phase auto set method added, string formatter changed, multiple bug fixed.


---------------------experiments and its conditions------------------------------
100Mohm_1e6 : 1e6V/A gain. measures OUTP? 1. also, waits 3 second.
               Waiting below 1s have phase adjust time error
               To avoid histerisis (which are not exsisting,,, obviously) meaured twice.

100Mohm_1e7 : 1e7V/A gain, the rest of the conditions are same

100Mohm_1e8 : 1e8V/A gain, ==

100Mohm_1e9 : 1e9V/A, Overload possible, 


100kohm_1e5 : 1e5V/A, for 100kohm, gain over 1e6 are not possible, not proceeded.



